document.addEventListener('DOMContentLoaded', function() {
    const previewButton = document.getElementById('previewButton');
    const replaceButton = document.getElementById('replaceButton');
    const imageUrlInput = document.getElementById('imageUrl');
    const previewContainer = document.getElementById('previewContainer');

    previewButton.addEventListener('click', function() {
        const imageUrl = imageUrlInput.value;

        if (isValidUrl(imageUrl)) {
            previewContainer.innerHTML = `<img src="${imageUrl}" alt="プレビュー画像">`;
        } else {
            previewContainer.innerHTML = '<p>有効なURLを入力してください</p>';
        }
    });

    replaceButton.addEventListener('click', function() {
        const imageUrl = imageUrlInput.value;

        if (isValidUrl(imageUrl)) {
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    args: [imageUrl],
                    func: (imageUrl) => {
                        const images = document.getElementsByTagName('img');
                        for (let img of images) {
                            img.src = imageUrl;
                        }
                    }
                });
            });
        } else {
            previewContainer.innerHTML = '<p>有効なURLを入力してください</p>';
        }
    });

    function isValidUrl(urlString) {
        try {
            new URL(urlString);
            return true;
        } catch (e) {
            return false;
        }
    }
});
